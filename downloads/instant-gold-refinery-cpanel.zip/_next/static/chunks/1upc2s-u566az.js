(()=>{"use strict";(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,17993,e=>{var t=e.i(43476),a=e.i(71645);let i=[{year:"2019",title:"The first furnace",body:"Instant Gold Refinery opens in Kenya with a single furnace and a promise: weigh, test and smelt in front of the client."},{year:"2020",title:"In-house assay lab",body:"XRF analysis brought in-house, so clients get purity results in minutes instead of days."},{year:"2021",title:"Fire assay",body:"Classical fire assay added for the highest-accuracy results on doré and high-value batches."},{year:"2022",title:"Refining line",body:"A chemical refining line takes output from doré to high-fineness gold."},{year:"2023",title:"Bullion casting",body:"Custom bar casting launched — bars poured to the client's chosen weight, stamped and documented."},{year:"2024",title:"Secure handling",body:"Upgraded secure premises and documented chain-of-custody for every gram that comes through the door."},{year:"Today",title:"Still instant",body:"Same-day smelting and assay for miners, dealers and jewellers — the promise we started with."}];function r({m:e,i:a,lit:i}){return(0,t.jsxs)("article",{className:`relative flex h-full flex-col justify-between rounded-[2rem] border p-8 transition duration-700 sm:p-10 ${i?"border-gold-300/40 bg-gradient-to-b from-ink-800 to-ink-900":"hairline bg-ink-900/60"}`,children:[(0,t.jsxs)("div",{className:"flex items-center justify-between font-mono text-[11px] uppercase tracking-[0.3em] text-dust",children:[(0,t.jsxs)("span",{children:["Chapter ",String(a+1).padStart(2,"0")]}),(0,t.jsx)("span",{className:`h-2.5 w-2.5 rounded-full transition ${i?"bg-gold-300 shadow-[0_0_16px_3px] shadow-gold-400/70":"bg-ink-600"}`})]}),(0,t.jsx)("p",{className:`mt-10 font-display text-[clamp(5rem,9vw,8.5rem)] leading-[0.8] tracking-tight transition duration-700 ${i?"text-gold":"text-transparent"}`,style:i?void 0:{WebkitTextStroke:"1px rgba(243,193,74,0.35)"},children:e.year}),(0,t.jsxs)("div",{className:"mt-10",children:[(0,t.jsx)("h3",{className:"font-display text-3xl text-bone sm:text-4xl",children:e.title}),(0,t.jsx)("p",{className:"mt-3 leading-relaxed text-dust",children:e.body})]})]})}e.s(["default",0,function(){let e=(0,a.useRef)(null),n=(0,a.useRef)(null),s=(0,a.useRef)(null),[o,l]=(0,a.useState)(0),[c,d]=(0,a.useState)(0);(0,a.useEffect)(()=>{let t=()=>{let t=e.current,a=n.current,i=s.current;if(!t||!a||!i)return;let r=t.getBoundingClientRect(),o=r.height-window.innerHeight,c=o>0?Math.max(0,Math.min(1,-r.top/o)):0;l(c),d(c*Math.max(0,i.offsetWidth-a.clientWidth))};return t(),window.addEventListener("scroll",t,{passive:!0}),window.addEventListener("resize",t),()=>{window.removeEventListener("scroll",t),window.removeEventListener("resize",t)}},[]);let m=Math.round(o*(i.length-1));return(0,t.jsxs)("section",{id:"timeline",className:"relative border-y hairline bg-ink-950",children:[(0,t.jsx)("div",{ref:e,className:"hidden lg:block",style:{height:`${60*i.length}vh`},children:(0,t.jsxs)("div",{className:"sticky top-0 flex h-screen flex-col justify-center overflow-hidden pt-20",children:[(0,t.jsxs)("div",{className:"mx-auto flex w-full max-w-7xl items-end justify-between px-6",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"font-mono text-[11px] uppercase tracking-[0.3em] text-gold-300",children:"Our journey"}),(0,t.jsxs)("h2",{className:"mt-4 font-display text-6xl leading-none text-bone",children:["From one furnace ",(0,t.jsx)("em",{className:"text-gold",children:"to today."})]})]}),(0,t.jsxs)("p",{className:"font-mono text-sm text-dust",children:[(0,t.jsx)("span",{className:"text-bone",children:String(m+1).padStart(2,"0")})," / ",String(i.length).padStart(2,"0")]})]}),(0,t.jsx)("div",{ref:n,className:"mt-10 overflow-hidden",children:(0,t.jsx)("div",{ref:s,className:"flex w-max gap-6 pl-[max(1.5rem,calc((100vw-80rem)/2+1.5rem))] pr-[6vw] will-change-transform",style:{transform:`translate3d(${-c}px,0,0)`},children:i.map((e,a)=>(0,t.jsx)("div",{className:"h-[50vh] min-h-[380px] max-h-[520px] w-[420px] shrink-0",children:(0,t.jsx)(r,{m:e,i:a,lit:a<=m})},e.year))})}),(0,t.jsxs)("div",{className:"mx-auto mt-10 w-full max-w-7xl px-6",children:[(0,t.jsx)("div",{className:"relative h-px bg-gold-300/15",children:(0,t.jsx)("div",{className:"absolute inset-y-0 left-0 bg-gradient-to-r from-gold-200 to-ember-500 shadow-[0_0_14px_2px] shadow-gold-400/50",style:{width:`${100*o}%`}})}),(0,t.jsx)("div",{className:"mt-4 flex justify-between font-mono text-[11px] uppercase tracking-[0.2em]",children:i.map((e,a)=>(0,t.jsx)("span",{className:a<=m?"text-gold-200":"text-dust/60",children:e.year},e.year))})]})]})}),(0,t.jsxs)("div",{className:"px-4 py-24 sm:px-6 lg:hidden",children:[(0,t.jsx)("p",{className:"reveal font-mono text-[11px] uppercase tracking-[0.3em] text-gold-300",children:"Our journey"}),(0,t.jsxs)("h2",{className:"reveal mt-4 font-display text-5xl leading-none text-bone",children:["From one furnace ",(0,t.jsx)("em",{className:"text-gold",children:"to today."})]}),(0,t.jsx)("div",{className:"mt-12 grid gap-4 sm:grid-cols-2",children:i.map((e,a)=>(0,t.jsx)("div",{className:"reveal",children:(0,t.jsx)(r,{m:e,i:a,lit:!0})},e.year))})]})]})}],17993)},69475,e=>{var t=e.i(43476),a=e.i(71645);let i=`
attribute vec2 p;
void main() { gl_Position = vec4(p, 0.0, 1.0); }
`,r=`
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform vec2 uMouse;
uniform float uIntensity;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, a = 0.5;
  mat2 r = mat2(0.8, -0.6, 0.6, 0.8);
  for (int i = 0; i < 5; i++) { v += a * noise(p); p = r * p * 2.0 + 3.1; a *= 0.5; }
  return v;
}
float field(vec2 p) {
  float t = uTime * 0.06;
  vec2 q = vec2(fbm(p + t), fbm(p + vec2(5.2, 1.3) - t));
  vec2 r = vec2(fbm(p + 3.0 * q + vec2(1.7, 9.2) + t * 1.5), fbm(p + 3.0 * q + vec2(8.3, 2.8) - t));
  float h = fbm(p + 2.5 * r);
  // cursor ripple
  vec2 m = uMouse * vec2(uRes.x / uRes.y, 1.0);
  float d = length(p / 2.2 - m);
  h += 0.06 * sin(d * 28.0 - uTime * 3.0) * exp(-d * 5.0);
  return h;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 p = (gl_FragCoord.xy / uRes.y) * 2.2;

  float e = 0.004;
  float h = field(p);
  vec3 n = normalize(vec3(field(p + vec2(e, 0.0)) - h, field(p + vec2(0.0, e)) - h, e * 0.9));

  vec3 L = normalize(vec3(-0.4, 0.6, 0.7));
  vec3 V = vec3(0.0, 0.0, 1.0);
  float diff = clamp(dot(n, L), 0.0, 1.0);
  float spec = pow(clamp(dot(reflect(-L, n), V), 0.0, 1.0), 38.0);
  float fres = pow(1.0 - clamp(dot(n, V), 0.0, 1.0), 3.0);

  vec3 deep = vec3(0.24, 0.12, 0.02);
  vec3 gold = vec3(0.86, 0.56, 0.12);
  vec3 bright = vec3(1.0, 0.86, 0.48);
  vec3 col = mix(deep, gold, smoothstep(0.25, 0.85, h));
  col = col * (0.35 + 0.9 * diff) + bright * spec * 1.4 + vec3(1.0, 0.6, 0.2) * fres * 0.5;

  // ember hot spots
  col += vec3(1.0, 0.35, 0.05) * smoothstep(0.72, 0.95, h) * 0.35;

  // fade to ink at edges / top so text stays readable
  float vig = smoothstep(1.25, 0.2, length((uv - vec2(0.62, 0.1)) * vec2(1.1, 1.5)));
  col *= mix(0.08, 1.0, vig) * uIntensity;
  gl_FragColor = vec4(col, 1.0);
}
`;e.s(["default",0,function({className:e="",intensity:n=1}){let s=(0,a.useRef)(null);return(0,a.useEffect)(()=>{let e=s.current;if(!e)return;let t=e.getContext("webgl",{antialias:!1,alpha:!1,powerPreference:"low-power"});if(!t){e.style.background="radial-gradient(ellipse at 60% 100%, #7a510a, #1d140c 55%, #070605)";return}let a=(e,a)=>{let i=t.createShader(e);return t.shaderSource(i,a),t.compileShader(i),i},o=t.createProgram();if(t.attachShader(o,a(t.VERTEX_SHADER,i)),t.attachShader(o,a(t.FRAGMENT_SHADER,r)),t.linkProgram(o),!t.getProgramParameter(o,t.LINK_STATUS))return;t.useProgram(o);let l=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,l),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),t.STATIC_DRAW);let c=t.getAttribLocation(o,"p");t.enableVertexAttribArray(c),t.vertexAttribPointer(c,2,t.FLOAT,!1,0,0);let d=t.getUniformLocation(o,"uRes"),m=t.getUniformLocation(o,"uTime"),h=t.getUniformLocation(o,"uMouse");t.uniform1f(t.getUniformLocation(o,"uIntensity"),n);let f=()=>{let a=.6*Math.min(window.devicePixelRatio||1,1.5),{width:i,height:r}=e.getBoundingClientRect();e.width=Math.max(1,Math.round(i*a)),e.height=Math.max(1,Math.round(r*a)),t.viewport(0,0,e.width,e.height),t.uniform2f(d,e.width,e.height)};f();let u=new ResizeObserver(f);u.observe(e);let x={x:.6,y:.4,tx:.6,ty:.4},p=t=>{let a=e.getBoundingClientRect();x.tx=(t.clientX-a.left)/a.width,x.ty=1-(t.clientY-a.top)/a.height};window.addEventListener("pointermove",p,{passive:!0});let g=!0,v=new IntersectionObserver(([e])=>g=e.isIntersecting);v.observe(e);let y=window.matchMedia("(prefers-reduced-motion: reduce)").matches,b=performance.now(),w=0,j=()=>{y||(w=requestAnimationFrame(j)),(g||y)&&(x.x+=(x.tx-x.x)*.06,x.y+=(x.ty-x.y)*.06,t.uniform1f(m,y?12:(performance.now()-b)/1e3+12),t.uniform2f(h,x.x,x.y),t.drawArrays(t.TRIANGLES,0,3))};return j(),()=>{cancelAnimationFrame(w),u.disconnect(),v.disconnect(),window.removeEventListener("pointermove",p),t.getExtension("WEBGL_lose_context")?.loseContext()}},[n]),(0,t.jsx)("canvas",{ref:s,className:e,"aria-hidden":"true"})}])}])})();
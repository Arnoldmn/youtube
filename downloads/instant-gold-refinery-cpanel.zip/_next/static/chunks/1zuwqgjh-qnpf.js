(()=>{"use strict";(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,82073,e=>{var t=e.i(43476),r=e.i(71645),a=e.i(25413),n=e.i(31338);let i=[{k:9,fineness:"375",note:"Common in budget jewellery. Heavy in copper and silver."},{k:14,fineness:"585",note:"Durable everyday jewellery. Just over half gold."},{k:18,fineness:"750",note:"Fine jewellery standard. Three parts gold in four."},{k:22,fineness:"916",note:"Traditional high-purity jewellery and coins."},{k:24,fineness:"999.9",note:"Investment-grade bullion. What leaves our refinery."}],l=(e,t,r)=>Math.round(e+(t-e)*r);e.s(["default",0,function(){let e,o,[s,d]=(0,r.useState)(i.length-1),c=i[s],m=String(Number(c.fineness)/10),u=(e=(c.k-9)/15,o=`rgb(${l(246,255,e)}, ${l(214,236,e)}, ${l(168,150,e)})`,{hi:o,mid:`rgb(${l(196,240,e)}, ${l(150,182,e)}, ${l(104,40,e)})`,lo:`rgb(${l(120,150,e)}, ${l(84,98,e)}, ${l(60,8,e)})`});return(0,t.jsx)("section",{id:"purity",className:"relative py-28 sm:py-36",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-4 sm:px-6",children:[(0,t.jsx)(a.f,{eyebrow:"Know your metal",title:(0,t.jsxs)(t.Fragment,{children:["Not all gold is ",(0,t.jsx)("em",{className:"text-gold",children:"gold."})]}),intro:"Slide through the karats to see how purity changes the colour and the value. We tell you exactly where your metal sits — before we make an offer."}),(0,t.jsxs)("div",{className:"mt-16 grid items-center gap-10 overflow-hidden rounded-[2.5rem] border hairline bg-gradient-to-br from-ink-800 to-ink-950 p-6 sm:p-12 lg:grid-cols-2",children:[(0,t.jsxs)("div",{className:"relative grid min-h-[320px] place-items-center",children:[(0,t.jsx)("div",{className:"absolute h-64 w-64 rounded-full blur-[90px] transition-colors duration-700",style:{background:u.mid,opacity:.35}}),(0,t.jsx)("div",{className:"relative w-full max-w-sm [perspective:900px]",children:(0,t.jsxs)("div",{className:"relative transition-transform duration-700 [transform:rotateX(52deg)_rotateZ(-28deg)] [transform-style:preserve-3d]",children:[(0,t.jsx)("div",{className:"relative h-40 rounded-xl transition-[background] duration-700",style:{background:`linear-gradient(135deg, ${u.hi} 0%, ${u.mid} 45%, ${u.lo} 100%)`,boxShadow:`0 40px 60px -20px ${u.lo}`},children:(0,t.jsx)("div",{className:"absolute inset-3 grid place-items-center rounded-lg border border-black/15 bg-gradient-to-br from-white/25 to-transparent",children:(0,t.jsxs)("div",{className:"text-center text-black/55",children:[(0,t.jsxs)("p",{className:"font-display text-5xl leading-none",children:[c.k,"K"]}),(0,t.jsxs)("p",{className:"mt-1 font-mono text-[11px] tracking-[0.3em]",children:["FINE ",c.fineness]}),(0,t.jsx)("p",{className:"mt-1 font-mono text-[9px] tracking-[0.3em]",children:"INSTANT GOLD"})]})})}),(0,t.jsx)("div",{className:"absolute left-0 right-0 top-full h-8 origin-top rounded-b-xl [transform:rotateX(-90deg)]",style:{background:u.lo}})]})})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex items-baseline gap-4",children:[(0,t.jsx)("span",{className:"font-display text-8xl leading-none text-bone sm:text-9xl",children:m}),(0,t.jsx)("span",{className:"font-display text-4xl text-dust",children:"% gold"})]}),(0,t.jsx)("p",{className:"mt-4 min-h-[3.5rem] max-w-md text-lg text-dust",children:c.note}),(0,t.jsxs)("div",{className:"mt-10",children:[(0,t.jsx)("label",{htmlFor:"karat",className:"sr-only",children:"Gold karat"}),(0,t.jsx)("input",{id:"karat",type:"range",min:0,max:i.length-1,step:1,value:s,onChange:e=>d(Number(e.target.value)),className:"w-full cursor-pointer appearance-none bg-transparent [&::-moz-range-thumb]:h-7 [&::-moz-range-thumb]:w-7 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-gold-200 [&::-moz-range-track]:h-1.5 [&::-moz-range-track]:rounded-full [&::-moz-range-track]:bg-ink-600 [&::-webkit-slider-runnable-track]:h-1.5 [&::-webkit-slider-runnable-track]:rounded-full [&::-webkit-slider-runnable-track]:bg-ink-600 [&::-webkit-slider-thumb]:-mt-[11px] [&::-webkit-slider-thumb]:h-7 [&::-webkit-slider-thumb]:w-7 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-gold-200 [&::-webkit-slider-thumb]:shadow-[0_0_20px_4px_rgba(243,193,74,0.5)]","aria-valuetext":`${c.k} karat, ${m}% gold`}),(0,t.jsx)("div",{className:"mt-4 flex justify-between",children:i.map((e,r)=>(0,t.jsxs)("button",{type:"button",onClick:()=>d(r),className:`rounded-full px-3 py-1 font-mono text-xs transition ${r===s?"bg-gold-300 text-ink-950":"text-dust hover:text-bone"}`,children:[e.k,"K"]},e.k))})]}),(0,t.jsxs)("a",{href:(0,n.x)(`Hello, I have ${c.k}K gold and would like an assay and a quote.`),target:"_blank",rel:"noopener noreferrer",className:"mt-10 inline-flex items-center gap-2 border-b border-gold-300/40 pb-1 text-gold-200 transition hover:border-gold-200",children:["Get a quote for your ",c.k,"K gold →"]})]})]})]})})}])},25413,e=>{var t=e.i(43476);e.s(["f",0,function({index:e,eyebrow:r,title:a,intro:n}){return(0,t.jsxs)("div",{className:"grid gap-6 lg:grid-cols-12 lg:items-end",children:[(0,t.jsxs)("div",{className:"lg:col-span-7",children:[(0,t.jsxs)("p",{className:"reveal flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.3em] text-gold-300",children:[e&&(0,t.jsx)("span",{className:"text-dust",children:e}),(0,t.jsx)("span",{className:"h-px w-10 bg-gold-300/40"}),r]}),(0,t.jsx)("h2",{className:"reveal mt-5 font-display text-[clamp(2.5rem,5.5vw,4.75rem)] leading-[0.98] tracking-[-0.015em] text-bone",style:{"--delay":"100ms"},children:a})]}),n&&(0,t.jsx)("p",{className:"reveal text-lg leading-relaxed text-dust lg:col-span-5",style:{"--delay":"200ms"},children:n})]})}])},97839,e=>{var t=e.i(43476),r=e.i(71645);e.s(["default",0,function({className:e=""}){let a=(0,r.useRef)(null);return(0,r.useEffect)(()=>{let e=a.current;if(!e)return;let t=e.getContext("2d");if(!t||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;let r=1,n=()=>{let t=Math.min(window.devicePixelRatio||1,2),{width:a}=e.getBoundingClientRect();e.width=a*t,e.height=a*t,r=a*t/800};n();let i=new ResizeObserver(n);i.observe(e);let l=[],o=(e,t)=>e+Math.random()*(t-e),s=()=>{let e=o(-(.95*Math.PI),-(.05*Math.PI)),t=o(2.5,7.5);l.push({x:630+o(-10,10),y:636,vx:Math.cos(e)*t,vy:Math.sin(e)*t,life:0,max:o(30,70),size:o(1,2.4),hue:o(35,52),ember:!1})},d=0,c=!0,m=new IntersectionObserver(([e])=>{c=e.isIntersecting});m.observe(e);let u=()=>{if(d=requestAnimationFrame(u),c){for(let e=0;e<4;e++)s();.6>Math.random()&&l.push({x:609+o(-4,6),y:474,vx:o(-.6,1.6),vy:o(-2.5,.5),life:0,max:o(25,45),size:o(.8,1.6),hue:o(40,55),ember:!1}),.35>Math.random()&&l.push({x:o(60,260),y:o(420,620),vx:o(-.2,.5),vy:o(-1.4,-.5),life:0,max:o(140,260),size:o(.8,2),hue:o(18,38),ember:!0}),t.setTransform(1,0,0,1,0,0),t.clearRect(0,0,e.width,e.height),t.setTransform(r,0,0,r,0,0),t.globalCompositeOperation="lighter";for(let e=l.length-1;e>=0;e--){let r=l[e];r.life++,r.ember?r.vx+=.02*Math.sin((r.life+r.x)*.05):(r.vy+=.22,r.vx*=.985);let a=r.x,n=r.y;r.x+=r.vx,r.y+=r.vy,!r.ember&&r.y>664&&r.vy>0&&(r.y=664,r.vy*=-.3,r.vx*=.6);let i=r.life/r.max;if(i>=1){l.splice(e,1);continue}let o=(1-i)*(r.ember?Math.min(1,r.life/20):1),s=85-35*i;t.strokeStyle=`hsla(${r.hue}, 100%, ${s}%, ${o})`,t.lineWidth=r.size,t.lineCap="round",t.beginPath(),t.moveTo(a-r.vx*(r.ember?1:1.8),n-r.vy*(r.ember?1:1.8)),t.lineTo(r.x,r.y),t.stroke()}}};return d=requestAnimationFrame(u),()=>{cancelAnimationFrame(d),i.disconnect(),m.disconnect()}},[]),(0,t.jsx)("canvas",{ref:a,className:e,"aria-hidden":"true"})}],97839)},69475,e=>{var t=e.i(43476),r=e.i(71645);let a=`
attribute vec2 p;
void main() { gl_Position = vec4(p, 0.0, 1.0); }
`,n=`
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform vec2 uMouse;
uniform float uIntensity;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, a = 0.5;
  mat2 r = mat2(0.8, -0.6, 0.6, 0.8);
  for (int i = 0; i < 5; i++) { v += a * noise(p); p = r * p * 2.0 + 3.1; a *= 0.5; }
  return v;
}
float field(vec2 p) {
  float t = uTime * 0.06;
  vec2 q = vec2(fbm(p + t), fbm(p + vec2(5.2, 1.3) - t));
  vec2 r = vec2(fbm(p + 3.0 * q + vec2(1.7, 9.2) + t * 1.5), fbm(p + 3.0 * q + vec2(8.3, 2.8) - t));
  float h = fbm(p + 2.5 * r);
  // cursor ripple
  vec2 m = uMouse * vec2(uRes.x / uRes.y, 1.0);
  float d = length(p / 2.2 - m);
  h += 0.06 * sin(d * 28.0 - uTime * 3.0) * exp(-d * 5.0);
  return h;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 p = (gl_FragCoord.xy / uRes.y) * 2.2;

  float e = 0.004;
  float h = field(p);
  vec3 n = normalize(vec3(field(p + vec2(e, 0.0)) - h, field(p + vec2(0.0, e)) - h, e * 0.9));

  vec3 L = normalize(vec3(-0.4, 0.6, 0.7));
  vec3 V = vec3(0.0, 0.0, 1.0);
  float diff = clamp(dot(n, L), 0.0, 1.0);
  float spec = pow(clamp(dot(reflect(-L, n), V), 0.0, 1.0), 38.0);
  float fres = pow(1.0 - clamp(dot(n, V), 0.0, 1.0), 3.0);

  vec3 deep = vec3(0.24, 0.12, 0.02);
  vec3 gold = vec3(0.86, 0.56, 0.12);
  vec3 bright = vec3(1.0, 0.86, 0.48);
  vec3 col = mix(deep, gold, smoothstep(0.25, 0.85, h));
  col = col * (0.35 + 0.9 * diff) + bright * spec * 1.4 + vec3(1.0, 0.6, 0.2) * fres * 0.5;

  // ember hot spots
  col += vec3(1.0, 0.35, 0.05) * smoothstep(0.72, 0.95, h) * 0.35;

  // fade to ink at edges / top so text stays readable
  float vig = smoothstep(1.25, 0.2, length((uv - vec2(0.62, 0.1)) * vec2(1.1, 1.5)));
  col *= mix(0.08, 1.0, vig) * uIntensity;
  gl_FragColor = vec4(col, 1.0);
}
`;e.s(["default",0,function({className:e="",intensity:i=1}){let l=(0,r.useRef)(null);return(0,r.useEffect)(()=>{let e=l.current;if(!e)return;let t=e.getContext("webgl",{antialias:!1,alpha:!1,powerPreference:"low-power"});if(!t){e.style.background="radial-gradient(ellipse at 60% 100%, #7a510a, #1d140c 55%, #070605)";return}let r=(e,r)=>{let a=t.createShader(e);return t.shaderSource(a,r),t.compileShader(a),a},o=t.createProgram();if(t.attachShader(o,r(t.VERTEX_SHADER,a)),t.attachShader(o,r(t.FRAGMENT_SHADER,n)),t.linkProgram(o),!t.getProgramParameter(o,t.LINK_STATUS))return;t.useProgram(o);let s=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,s),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),t.STATIC_DRAW);let d=t.getAttribLocation(o,"p");t.enableVertexAttribArray(d),t.vertexAttribPointer(d,2,t.FLOAT,!1,0,0);let c=t.getUniformLocation(o,"uRes"),m=t.getUniformLocation(o,"uTime"),u=t.getUniformLocation(o,"uMouse");t.uniform1f(t.getUniformLocation(o,"uIntensity"),i);let h=()=>{let r=.6*Math.min(window.devicePixelRatio||1,1.5),{width:a,height:n}=e.getBoundingClientRect();e.width=Math.max(1,Math.round(a*r)),e.height=Math.max(1,Math.round(n*r)),t.viewport(0,0,e.width,e.height),t.uniform2f(c,e.width,e.height)};h();let f=new ResizeObserver(h);f.observe(e);let x={x:.6,y:.4,tx:.6,ty:.4},g=t=>{let r=e.getBoundingClientRect();x.tx=(t.clientX-r.left)/r.width,x.ty=1-(t.clientY-r.top)/r.height};window.addEventListener("pointermove",g,{passive:!0});let p=!0,v=new IntersectionObserver(([e])=>p=e.isIntersecting);v.observe(e);let b=window.matchMedia("(prefers-reduced-motion: reduce)").matches,y=performance.now(),w=0,k=()=>{b||(w=requestAnimationFrame(k)),(p||b)&&(x.x+=(x.tx-x.x)*.06,x.y+=(x.ty-x.y)*.06,t.uniform1f(m,b?12:(performance.now()-y)/1e3+12),t.uniform2f(u,x.x,x.y),t.drawArrays(t.TRIANGLES,0,3))};return k(),()=>{cancelAnimationFrame(w),f.disconnect(),v.disconnect(),window.removeEventListener("pointermove",g),t.getExtension("WEBGL_lose_context")?.loseContext()}},[i]),(0,t.jsx)("canvas",{ref:l,className:e,"aria-hidden":"true"})}])}])})();
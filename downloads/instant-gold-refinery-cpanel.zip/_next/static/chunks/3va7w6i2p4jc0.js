(()=>{"use strict";(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,71030,e=>{var t=e.i(43476),i=e.i(71645),a=e.i(25413);let r=[{title:"Receive & weigh",body:"Your material is logged and weighed on calibrated scales — in front of you, with a written receipt."},{title:"Assay",body:"A sample is tested by fire assay or XRF so the gold content is known before anything is melted."},{title:"Smelt",body:"Fluxes and heat above 1,064 °C separate gold from slag inside our furnaces."},{title:"Refine",body:"Impurities like silver and copper are chemically removed for high-fineness output."},{title:"Cast",body:"Pure metal is poured into moulds and cooled into bars of the agreed weight."},{title:"Certify & settle",body:"Final weight and purity are documented. Collect your bars or get paid — same day where possible."}];e.s(["default",0,function({heading:e=!0}){let s=(0,i.useRef)(null),[l,o]=(0,i.useState)(0);(0,i.useEffect)(()=>{let e=s.current;if(!e)return;let t=()=>{let t=e.getBoundingClientRect();o(Math.max(0,Math.min(1,(.6*window.innerHeight-t.top)/t.height)))};return t(),window.addEventListener("scroll",t,{passive:!0}),window.addEventListener("resize",t),()=>{window.removeEventListener("scroll",t),window.removeEventListener("resize",t)}},[]);let n=Math.min(r.length-1,Math.floor(l*r.length));return(0,t.jsxs)("section",{id:"process",className:"relative overflow-clip border-y hairline bg-ink-900 py-28 sm:py-36",children:[(0,t.jsx)("div",{"aria-hidden":"true",className:"absolute left-1/2 top-0 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-ember-600/10 blur-[160px]"}),(0,t.jsxs)("div",{className:"relative mx-auto max-w-7xl px-4 sm:px-6",children:[e&&(0,t.jsx)(a.f,{eyebrow:"The process",title:(0,t.jsxs)(t.Fragment,{children:["Six steps. ",(0,t.jsx)("em",{className:"text-gold",children:"Zero"})," guesswork."]}),intro:"Transparency is the whole business. You see the scale, you see the assay, you see the pour."}),(0,t.jsxs)("div",{className:`grid gap-12 lg:grid-cols-12 ${e?"mt-20":""}`,children:[(0,t.jsx)("div",{className:"hidden lg:col-span-5 lg:block",children:(0,t.jsxs)("div",{className:"sticky top-32 overflow-hidden rounded-3xl border hairline bg-ink-950/60 p-10",children:[(0,t.jsx)("p",{className:"font-mono text-[11px] uppercase tracking-[0.3em] text-dust",children:"Now at step"}),(0,t.jsx)("p",{className:"mt-4 font-display text-[10rem] leading-none text-gold",children:String(n+1).padStart(2,"0")}),(0,t.jsx)("p",{className:"mt-2 font-display text-3xl italic text-bone",children:r[n].title}),(0,t.jsx)("div",{className:"mt-10 h-1.5 overflow-hidden rounded-full bg-ink-700",children:(0,t.jsx)("div",{className:"h-full rounded-full bg-gradient-to-r from-gold-200 to-ember-500 transition-[width] duration-300",style:{width:`${Math.max(4,100*l)}%`}})}),(0,t.jsxs)("div",{className:"mt-3 flex justify-between font-mono text-[10px] uppercase tracking-[0.2em] text-dust",children:[(0,t.jsx)("span",{children:"Raw"}),(0,t.jsx)("span",{children:"Bullion"})]})]})}),(0,t.jsxs)("ol",{ref:s,className:"relative grid gap-y-14 lg:col-span-7 lg:gap-y-24 lg:py-6",children:[(0,t.jsx)("span",{"aria-hidden":"true",className:"absolute bottom-2 left-[19px] top-2 w-px bg-gold-300/15"}),(0,t.jsx)("span",{"aria-hidden":"true",className:"absolute left-[18px] top-2 w-[3px] rounded-full bg-gradient-to-b from-gold-100 via-gold-300 to-ember-500 shadow-[0_0_18px_2px] shadow-gold-400/60",style:{height:`calc(${100*l}% - 16px)`}}),r.map((e,i)=>{let a=l*r.length>i+.3;return(0,t.jsxs)("li",{className:"relative grid grid-cols-[40px_1fr] gap-6",children:[(0,t.jsx)("span",{className:`relative z-10 grid h-10 w-10 place-items-center rounded-full border font-mono text-xs transition duration-500 ${a?"border-gold-300 bg-gold-300 text-ink-950 shadow-[0_0_24px] shadow-gold-400/70":"hairline bg-ink-900 text-dust"}`,children:String(i+1).padStart(2,"0")}),(0,t.jsxs)("div",{className:`transition duration-700 ${a?"opacity-100":"opacity-40"}`,children:[(0,t.jsx)("h3",{className:"font-display text-3xl text-bone sm:text-4xl",children:e.title}),(0,t.jsx)("p",{className:"mt-2 max-w-lg leading-relaxed text-dust",children:e.body})]})]},e.title)})]})]})]})]})}])},25413,e=>{var t=e.i(43476);e.s(["f",0,function({index:e,eyebrow:i,title:a,intro:r}){return(0,t.jsxs)("div",{className:"grid gap-6 lg:grid-cols-12 lg:items-end",children:[(0,t.jsxs)("div",{className:"lg:col-span-7",children:[(0,t.jsxs)("p",{className:"reveal flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.3em] text-gold-300",children:[e&&(0,t.jsx)("span",{className:"text-dust",children:e}),(0,t.jsx)("span",{className:"h-px w-10 bg-gold-300/40"}),i]}),(0,t.jsx)("h2",{className:"reveal mt-5 font-display text-[clamp(2.5rem,5.5vw,4.75rem)] leading-[0.98] tracking-[-0.015em] text-bone",style:{"--delay":"100ms"},children:a})]}),r&&(0,t.jsx)("p",{className:"reveal text-lg leading-relaxed text-dust lg:col-span-5",style:{"--delay":"200ms"},children:r})]})}])},69475,e=>{var t=e.i(43476),i=e.i(71645);let a=`
attribute vec2 p;
void main() { gl_Position = vec4(p, 0.0, 1.0); }
`,r=`
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform vec2 uMouse;
uniform float uIntensity;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, a = 0.5;
  mat2 r = mat2(0.8, -0.6, 0.6, 0.8);
  for (int i = 0; i < 5; i++) { v += a * noise(p); p = r * p * 2.0 + 3.1; a *= 0.5; }
  return v;
}
float field(vec2 p) {
  float t = uTime * 0.06;
  vec2 q = vec2(fbm(p + t), fbm(p + vec2(5.2, 1.3) - t));
  vec2 r = vec2(fbm(p + 3.0 * q + vec2(1.7, 9.2) + t * 1.5), fbm(p + 3.0 * q + vec2(8.3, 2.8) - t));
  float h = fbm(p + 2.5 * r);
  // cursor ripple
  vec2 m = uMouse * vec2(uRes.x / uRes.y, 1.0);
  float d = length(p / 2.2 - m);
  h += 0.06 * sin(d * 28.0 - uTime * 3.0) * exp(-d * 5.0);
  return h;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 p = (gl_FragCoord.xy / uRes.y) * 2.2;

  float e = 0.004;
  float h = field(p);
  vec3 n = normalize(vec3(field(p + vec2(e, 0.0)) - h, field(p + vec2(0.0, e)) - h, e * 0.9));

  vec3 L = normalize(vec3(-0.4, 0.6, 0.7));
  vec3 V = vec3(0.0, 0.0, 1.0);
  float diff = clamp(dot(n, L), 0.0, 1.0);
  float spec = pow(clamp(dot(reflect(-L, n), V), 0.0, 1.0), 38.0);
  float fres = pow(1.0 - clamp(dot(n, V), 0.0, 1.0), 3.0);

  vec3 deep = vec3(0.24, 0.12, 0.02);
  vec3 gold = vec3(0.86, 0.56, 0.12);
  vec3 bright = vec3(1.0, 0.86, 0.48);
  vec3 col = mix(deep, gold, smoothstep(0.25, 0.85, h));
  col = col * (0.35 + 0.9 * diff) + bright * spec * 1.4 + vec3(1.0, 0.6, 0.2) * fres * 0.5;

  // ember hot spots
  col += vec3(1.0, 0.35, 0.05) * smoothstep(0.72, 0.95, h) * 0.35;

  // fade to ink at edges / top so text stays readable
  float vig = smoothstep(1.25, 0.2, length((uv - vec2(0.62, 0.1)) * vec2(1.1, 1.5)));
  col *= mix(0.08, 1.0, vig) * uIntensity;
  gl_FragColor = vec4(col, 1.0);
}
`;e.s(["default",0,function({className:e="",intensity:s=1}){let l=(0,i.useRef)(null);return(0,i.useEffect)(()=>{let e=l.current;if(!e)return;let t=e.getContext("webgl",{antialias:!1,alpha:!1,powerPreference:"low-power"});if(!t){e.style.background="radial-gradient(ellipse at 60% 100%, #7a510a, #1d140c 55%, #070605)";return}let i=(e,i)=>{let a=t.createShader(e);return t.shaderSource(a,i),t.compileShader(a),a},o=t.createProgram();if(t.attachShader(o,i(t.VERTEX_SHADER,a)),t.attachShader(o,i(t.FRAGMENT_SHADER,r)),t.linkProgram(o),!t.getProgramParameter(o,t.LINK_STATUS))return;t.useProgram(o);let n=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,n),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),t.STATIC_DRAW);let d=t.getAttribLocation(o,"p");t.enableVertexAttribArray(d),t.vertexAttribPointer(d,2,t.FLOAT,!1,0,0);let c=t.getUniformLocation(o,"uRes"),m=t.getUniformLocation(o,"uTime"),p=t.getUniformLocation(o,"uMouse");t.uniform1f(t.getUniformLocation(o,"uIntensity"),s);let h=()=>{let i=.6*Math.min(window.devicePixelRatio||1,1.5),{width:a,height:r}=e.getBoundingClientRect();e.width=Math.max(1,Math.round(a*i)),e.height=Math.max(1,Math.round(r*i)),t.viewport(0,0,e.width,e.height),t.uniform2f(c,e.width,e.height)};h();let u=new ResizeObserver(h);u.observe(e);let f={x:.6,y:.4,tx:.6,ty:.4},g=t=>{let i=e.getBoundingClientRect();f.tx=(t.clientX-i.left)/i.width,f.ty=1-(t.clientY-i.top)/i.height};window.addEventListener("pointermove",g,{passive:!0});let x=!0,v=new IntersectionObserver(([e])=>x=e.isIntersecting);v.observe(e);let b=window.matchMedia("(prefers-reduced-motion: reduce)").matches,w=performance.now(),y=0,j=()=>{b||(y=requestAnimationFrame(j)),(x||b)&&(f.x+=(f.tx-f.x)*.06,f.y+=(f.ty-f.y)*.06,t.uniform1f(m,b?12:(performance.now()-w)/1e3+12),t.uniform2f(p,f.x,f.y),t.drawArrays(t.TRIANGLES,0,3))};return j(),()=>{cancelAnimationFrame(y),u.disconnect(),v.disconnect(),window.removeEventListener("pointermove",g),t.getExtension("WEBGL_lose_context")?.loseContext()}},[s]),(0,t.jsx)("canvas",{ref:l,className:e,"aria-hidden":"true"})}])}])})();
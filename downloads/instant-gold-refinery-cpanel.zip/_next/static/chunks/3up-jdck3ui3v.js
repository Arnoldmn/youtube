(()=>{"use strict";(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,69475,e=>{var t=e.i(43476),r=e.i(71645);let a=`
attribute vec2 p;
void main() { gl_Position = vec4(p, 0.0, 1.0); }
`,i=`
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform vec2 uMouse;
uniform float uIntensity;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, a = 0.5;
  mat2 r = mat2(0.8, -0.6, 0.6, 0.8);
  for (int i = 0; i < 5; i++) { v += a * noise(p); p = r * p * 2.0 + 3.1; a *= 0.5; }
  return v;
}
float field(vec2 p) {
  float t = uTime * 0.06;
  vec2 q = vec2(fbm(p + t), fbm(p + vec2(5.2, 1.3) - t));
  vec2 r = vec2(fbm(p + 3.0 * q + vec2(1.7, 9.2) + t * 1.5), fbm(p + 3.0 * q + vec2(8.3, 2.8) - t));
  float h = fbm(p + 2.5 * r);
  // cursor ripple
  vec2 m = uMouse * vec2(uRes.x / uRes.y, 1.0);
  float d = length(p / 2.2 - m);
  h += 0.06 * sin(d * 28.0 - uTime * 3.0) * exp(-d * 5.0);
  return h;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 p = (gl_FragCoord.xy / uRes.y) * 2.2;

  float e = 0.004;
  float h = field(p);
  vec3 n = normalize(vec3(field(p + vec2(e, 0.0)) - h, field(p + vec2(0.0, e)) - h, e * 0.9));

  vec3 L = normalize(vec3(-0.4, 0.6, 0.7));
  vec3 V = vec3(0.0, 0.0, 1.0);
  float diff = clamp(dot(n, L), 0.0, 1.0);
  float spec = pow(clamp(dot(reflect(-L, n), V), 0.0, 1.0), 38.0);
  float fres = pow(1.0 - clamp(dot(n, V), 0.0, 1.0), 3.0);

  vec3 deep = vec3(0.24, 0.12, 0.02);
  vec3 gold = vec3(0.86, 0.56, 0.12);
  vec3 bright = vec3(1.0, 0.86, 0.48);
  vec3 col = mix(deep, gold, smoothstep(0.25, 0.85, h));
  col = col * (0.35 + 0.9 * diff) + bright * spec * 1.4 + vec3(1.0, 0.6, 0.2) * fres * 0.5;

  // ember hot spots
  col += vec3(1.0, 0.35, 0.05) * smoothstep(0.72, 0.95, h) * 0.35;

  // fade to ink at edges / top so text stays readable
  float vig = smoothstep(1.25, 0.2, length((uv - vec2(0.62, 0.1)) * vec2(1.1, 1.5)));
  col *= mix(0.08, 1.0, vig) * uIntensity;
  gl_FragColor = vec4(col, 1.0);
}
`;e.s(["default",0,function({className:e="",intensity:n=1}){let o=(0,r.useRef)(null);return(0,r.useEffect)(()=>{let e=o.current;if(!e)return;let t=e.getContext("webgl",{antialias:!1,alpha:!1,powerPreference:"low-power"});if(!t){e.style.background="radial-gradient(ellipse at 60% 100%, #7a510a, #1d140c 55%, #070605)";return}let r=(e,r)=>{let a=t.createShader(e);return t.shaderSource(a,r),t.compileShader(a),a},s=t.createProgram();if(t.attachShader(s,r(t.VERTEX_SHADER,a)),t.attachShader(s,r(t.FRAGMENT_SHADER,i)),t.linkProgram(s),!t.getProgramParameter(s,t.LINK_STATUS))return;t.useProgram(s);let l=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,l),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),t.STATIC_DRAW);let c=t.getAttribLocation(s,"p");t.enableVertexAttribArray(c),t.vertexAttribPointer(c,2,t.FLOAT,!1,0,0);let d=t.getUniformLocation(s,"uRes"),m=t.getUniformLocation(s,"uTime"),u=t.getUniformLocation(s,"uMouse");t.uniform1f(t.getUniformLocation(s,"uIntensity"),n);let f=()=>{let r=.6*Math.min(window.devicePixelRatio||1,1.5),{width:a,height:i}=e.getBoundingClientRect();e.width=Math.max(1,Math.round(a*r)),e.height=Math.max(1,Math.round(i*r)),t.viewport(0,0,e.width,e.height),t.uniform2f(d,e.width,e.height)};f();let p=new ResizeObserver(f);p.observe(e);let v={x:.6,y:.4,tx:.6,ty:.4},x=t=>{let r=e.getBoundingClientRect();v.tx=(t.clientX-r.left)/r.width,v.ty=1-(t.clientY-r.top)/r.height};window.addEventListener("pointermove",x,{passive:!0});let h=!0,g=new IntersectionObserver(([e])=>h=e.isIntersecting);g.observe(e);let b=window.matchMedia("(prefers-reduced-motion: reduce)").matches,y=performance.now(),w=0,A=()=>{b||(w=requestAnimationFrame(A)),(h||b)&&(v.x+=(v.tx-v.x)*.06,v.y+=(v.ty-v.y)*.06,t.uniform1f(m,b?12:(performance.now()-y)/1e3+12),t.uniform2f(u,v.x,v.y),t.drawArrays(t.TRIANGLES,0,3))};return A(),()=>{cancelAnimationFrame(w),p.disconnect(),g.disconnect(),window.removeEventListener("pointermove",x),t.getExtension("WEBGL_lose_context")?.loseContext()}},[n]),(0,t.jsx)("canvas",{ref:o,className:e,"aria-hidden":"true"})}])},16849,e=>{var t=e.i(43476),r=e.i(71645);let a=[{k:"Atomic number",v:"79"},{k:"Melting point",v:"1,064 °C"},{k:"Density",v:"19.32 g/cm³"},{k:"One troy ounce",v:"31.103 g"},{k:"24 karat",v:"≥ 99.9 % pure"},{k:"Tarnish & rust",v:"Never"}];e.s(["default",0,function(){let e=(0,r.useRef)(null),[i,n]=(0,r.useState)(0);return(0,r.useEffect)(()=>{let t=setInterval(()=>n(e=>(e+1)%a.length),2600),r=e.current,i={x:0,y:0},o={x:0,y:0},s=0,l=e=>{i.x=e.clientX/window.innerWidth-.5,i.y=e.clientY/window.innerHeight-.5},c=()=>{o.x+=(i.x-o.x)*.07,o.y+=(i.y-o.y)*.07,r&&(r.style.transform=`rotateY(${26*o.x-8}deg) rotateX(${-(22*o.y)+6}deg)`,r.style.setProperty("--gx",`${50+80*o.x}%`),r.style.setProperty("--gy",`${50+80*o.y}%`)),s=requestAnimationFrame(c)};return window.addEventListener("pointermove",l,{passive:!0}),s=requestAnimationFrame(c),()=>{clearInterval(t),cancelAnimationFrame(s),window.removeEventListener("pointermove",l)}},[]),(0,t.jsxs)("div",{className:"relative mx-auto grid aspect-square w-full max-w-[560px] place-items-center [perspective:1000px]",children:[(0,t.jsx)("div",{"aria-hidden":"true",className:"absolute inset-[15%] rounded-full bg-gold-400/25 blur-[90px]"}),(0,t.jsxs)("div",{ref:e,className:"relative -mt-[14%] aspect-[4/5] w-[60%] rounded-[2rem] border border-gold-200/40 p-[7%] shadow-[0_50px_100px_-30px_rgba(0,0,0,0.9)] [transform-style:preserve-3d]",style:{background:"linear-gradient(140deg, #fff3c4 0%, #f3c14a 28%, #c98b12 60%, #7a510a 100%)"},children:[(0,t.jsx)("div",{"aria-hidden":"true",className:"absolute inset-0 rounded-[2rem] mix-blend-overlay",style:{background:"radial-gradient(circle at var(--gx,50%) var(--gy,50%), rgba(255,255,255,0.85), transparent 45%)"}}),(0,t.jsxs)("div",{className:"relative flex h-full flex-col justify-between text-[#4a3005] [transform:translateZ(40px)]",children:[(0,t.jsxs)("div",{className:"flex justify-between font-mono text-sm sm:text-base",children:[(0,t.jsx)("span",{children:"79"}),(0,t.jsx)("span",{children:"196.967"})]}),(0,t.jsx)("p",{className:"font-display text-[clamp(6rem,16vw,11rem)] leading-[0.8] tracking-tight [text-shadow:0_2px_0_rgba(255,243,196,0.6)]",children:"Au"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"font-display text-3xl",children:"Gold"}),(0,t.jsx)("p",{className:"font-mono text-[10px] uppercase tracking-[0.3em] opacity-70",children:"Transition metal · Group 11"})]})]})]}),(0,t.jsxs)("div",{className:"absolute bottom-0 left-1/2 w-[80%] -translate-x-1/2 overflow-hidden rounded-2xl border hairline bg-ink-950/80 px-5 py-4 backdrop-blur-md sm:w-[70%]","aria-live":"polite",children:[(0,t.jsxs)("div",{className:"flex items-baseline justify-between gap-4 [animation:bubble-in_0.5s_ease-out]",children:[(0,t.jsx)("span",{className:"font-mono text-[10px] uppercase tracking-[0.25em] text-dust",children:a[i].k}),(0,t.jsx)("span",{className:"font-display text-2xl text-gold-200",children:a[i].v})]},i),(0,t.jsx)("div",{className:"mt-3 flex gap-1",children:a.map((e,r)=>(0,t.jsx)("span",{className:`h-0.5 flex-1 rounded-full transition-colors duration-500 ${r===i?"bg-gold-300":"bg-gold-300/15"}`},r))})]})]})}])}])})();